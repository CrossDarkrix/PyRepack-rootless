sudo dpkg -i karenprefs_1.5.deb
sudo dpkg -i nodelete-net.angelxwind.airspeaker
をした後、

・_airspeaker
・_AirSpeakerServer

を[RootHideBootsrapRootDirectory]/usr/bin/に投げ込む。

※「RootHideBootsrapRootDirectory」がわからない場合はNewTermでpwd -Pをすると確認できる。
